# ft_package

Ceci est un package Python simple pour compter les occurrences d'un élément
dans une liste.

## Utilisation

```python
from ft_package import count_in_list

ma_liste = [1, 2, 3, 2, 4, 2]
count = count_in_list(ma_liste, 2)
print(count)  # Output: 3
